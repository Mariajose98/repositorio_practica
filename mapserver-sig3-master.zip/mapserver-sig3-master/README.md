# mapserver-sig3
Practica Mapserver Curso SIG3


## Instalar Vbox Additions

## EN EL HOST

ruta carpeta:    

```
c:\compartido
```

nombre carpeta:  

```
compartido
```

punto de montaje: 

```
/var/www/html/sig3
```


## EN LA MAQUINA VIRTUAL

```
sudo mkdir /var/www/html/sig3
```

```
sudo mount -t vboxsf compartido /var/www/html/sig3
```


## EXAMPLES 

```
shp2img -m ejemplo1.map -o tmp/ejemplo1.png -i PNG
```

```
shp2img -m ejemplo2.map -o tmp/ejemplo2.png -i PNG
```

```
shp2img -m ejemplo3.map -o tmp/ejemplo3.png -i PNG
```

```
shp2img -m ejemplo4.map -o tmp/ejemplo4.png -i PNG
```

```
shp2img -m ejemplo5.map -o tmp/ejemplo5.png -i PNG
```

```
shp2img -m ejemplo6.map -o tmp/ejemplo6.png -i PNG
```

```
shp2img -m ejemplo8.map -o tmp/ejemplo8.png -i PNG
```

```
shp2img -m ejemplo9.map -o tmp/ejemplo9.png -i PNG
```

